
var obj = {
    name: 'NolBu',
    age: 30,
    'address': 'Seoul',
    100: '010-1234-5678'
};
console.log(obj);
console.log(obj.name);
console.log(obj.address);
console.log('');

console.log( obj['100'] );

var add = 'address';
console.log( obj[add] );


