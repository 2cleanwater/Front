<template>
    <div>
        <h3>Chap04 Slot</h3>

    </div>
</template>

<script>
export default {

}
</script>
