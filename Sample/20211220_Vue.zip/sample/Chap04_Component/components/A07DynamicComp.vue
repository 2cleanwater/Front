
<template>
    <div>
        <h3>A07 Dynamic Component</h3>

        <ul>
            <li><a href="#">HOME</a></li>
            <li><a href="#">ABOUT</a></li>
            <li><a href="#">Product</a></li>
        </ul>

        <div>
            
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            
        }
    },
    methods: {
        
    }
}
</script>

<style>

</style>