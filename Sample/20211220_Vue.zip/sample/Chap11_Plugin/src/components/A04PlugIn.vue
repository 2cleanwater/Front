<template>
    <div>
        <h3>A04 Plugin</h3>

        <div>
            Mixin: <br>
            Filter: <br>
            Prototype: <br>
            <br>

            <div>Hello World</div>
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>