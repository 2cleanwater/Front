<template>
    <div>
        <h3>A3 Directive</h3>

        <div>
            <input type="text" class="form-control">
        </div>
        <br>

        <div>Custom Directive</div>
        <br>
        
        <div>
            Alert Event
        </div>
    </div>
</template>
<script>
export default {
    data() {
        return {
            isChecked: true,
        }
    },

}
</script>