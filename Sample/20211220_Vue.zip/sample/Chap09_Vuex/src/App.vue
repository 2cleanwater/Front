<template>
  <div class="card-body">
    <A01Counter/>
  </div>
</template>

<script>
import A01Counter from './components/A01Counter.vue'
export default {
  name: 'App',
  components: {
    A01Counter
  }
}
</script>

<style>

</style>
