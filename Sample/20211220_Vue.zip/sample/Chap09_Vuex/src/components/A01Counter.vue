<template>
    <div>
        <h3>A01 Counter</h3>

        <div>
            Num: <br>
            <button>+</button>
            <button>-</button>
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>