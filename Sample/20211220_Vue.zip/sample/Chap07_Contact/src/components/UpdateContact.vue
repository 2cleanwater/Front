<template>
  <ContactForm></ContactForm>
</template>

<script>
import ContactForm from './ContactForm';
export default {
  components: {ContactForm}
}
</script>