<template>
    <div class="container-fluid">
        <h3>Add Contact</h3>

        Name: <input type="text" class="form-control" name="name" />
        Tel: <input type="text" class="form-control" name="tel" />
        Address: <input type="text" class="form-control" name="address" />
        <br />
        <button class="btn btn-outline-primary">ADD</button>
    </div>
</template>
<script>
export default {
    
}
</script>
