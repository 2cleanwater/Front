<template>
    <div class="container-fluid">
        <h3>Update Contact</h3>

        <div>
            Name: <input type="text" class="form-control" name="name" />
            Tel: <input type="text" class="form-control" name="tel" />
            Address: <input type="text" class="form-control" name="address" />
        </div>
        <br />
        <button class="btn btn-outline-primary">ADD</button>
    </div>
</template>
<script>
export default {
    
}
</script>