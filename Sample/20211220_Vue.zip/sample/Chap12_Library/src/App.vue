<template>
  <div class="card-body">
    <h1>Chap12 Library</h1>

    <A01JQuery></A01JQuery>
  </div>
</template>

<script>
import './../node_modules/bootstrap/dist/css/bootstrap.css'
import A01JQuery from './components/A01JQuery.vue'

export default {
  name: 'App',
  components: { A01JQuery, }
}
</script>

<style>

</style>
