<template>
    <div>
        <!-- npm install -D sass-loader@^10 sass -->
        <h3>A04 SASS</h3>

        <div>
            <div>Hello World</div>
            <div>Hello World</div>
        </div>
    </div>
</template>
