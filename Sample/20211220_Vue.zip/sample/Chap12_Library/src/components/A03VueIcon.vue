<template>
    <div>
        <h3>A03 Vue Icon</h3>

        <div>
            <!-- npm i bootstrap@4 bootstrap-vue
                https://bootstrap-vue.org/docs/icons/#bootstrap-icons
                https://icons.getbootstrap.com/#install
            -->
            <h5>Bootstrap ICON</h5>
            
        </div>

        <div>
            <!-- npm i vue-material-design-icons
                https://github.com/robcresswell/vue-material-design-icons
                https://materialdesignicons.com/
            -->
            <h5>Material ICON</h5>
            
        </div>

        <div>
            <!-- npm i vue-unicons
                https://github.com/antonreshetov/vue-unicons
            -->
            <h5>Unicon ICON</h5>
            
        </div>

    </div>
</template>

<script>
export default {
    components: {}
}
</script>