<template>
  <div class="card-body">
      <h1>Vue Router</h1>

      <div>

      </div>

      <hr>

      <div>
          
      </div>
  </div>
</template>

<script>
import A01Bind from './components/A01Bind.vue'

export default {
  name: 'App',
  
}
</script>

<style>

</style>
