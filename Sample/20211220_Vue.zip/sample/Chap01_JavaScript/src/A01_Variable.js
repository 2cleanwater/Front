console.log('name: ' + name + ' typeof: ' + typeof name);

var name = 'NolBu';
console.log('name: ' + name + ' typeof: ' + typeof name);

var name = 10;
console.log('name: ' + name + ' typeof: ' + typeof name);
