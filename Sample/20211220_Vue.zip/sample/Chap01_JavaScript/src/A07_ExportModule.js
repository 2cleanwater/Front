

let num = 10.25;

function onAdd(x, y) {
    return x + y;
}

function longNameFunction() {
    return 'longNameFunction';
}


