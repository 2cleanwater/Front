
let contactlist = {
    contacts : [
        { no:1001, name:'김유신', tel:'010-1212-3331', address:'경주' },
        { no:1002, name:'장보고', tel:'010-1212-3332', address:'청해진' },
        { no:1003, name:'관창', tel:'010-1212-3333', address:'황산벌' },
        { no:1004, name:'안중근', tel:'010-1212-3334', address:'해주' },
        { no:1005, name:'강감찬', tel:'010-1212-3335', address:'귀주' },
        { no:1006, name:'정몽주', tel:'010-1212-3336', address:'개성' },
        { no:1007, name:'이순신', tel:'010-1212-3337', address:'통제영' },
        { no:1008, name:'김시민', tel:'010-1212-3338', address:'진주' },
        { no:1009, name:'정약용', tel:'010-1212-3339', address:'남양주' }
    ]
}

export default contactlist;