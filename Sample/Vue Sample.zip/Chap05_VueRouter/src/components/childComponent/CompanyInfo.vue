
<template>
    <div>
        <h4>회사 소개</h4>

        <div>
            회사소개 상세 페이지..
        </div>
    </div>
</template>