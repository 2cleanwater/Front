<template>
  <div class="card-body">
    <A01Axios msg="Welcome to Your Vue.js App"/>
  </div>
</template>

<script>
import A01Axios from './components/A01Axios.vue'

export default {
  name: 'App',
  components: {
    A01Axios
  }
}
</script>

<style>

</style>
