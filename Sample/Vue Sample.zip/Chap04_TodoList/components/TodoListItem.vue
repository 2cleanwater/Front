
<template>
    <tr>
        <td></td>
        <td><span></span></td>
        <td>
            <button class="btn btn-primary">Complete</button>
        </td>
        <td>
            <button class="btn btn-danger">Delete</button>
        </td>
    </tr>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>