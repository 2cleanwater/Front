
import React from 'react';

const A02ProductComponent = () => {

    return (
        <div>
            <h5>Product Component</h5>
            <div>This is Product Component</div>
            <br />

            <div>
                <button>BACK</button>
                <button>FORWARD</button>
                <button>HOME</button>
                <button>PARAMETER</button>
            </div>
        </div>
    )
}
export default A02ProductComponent;