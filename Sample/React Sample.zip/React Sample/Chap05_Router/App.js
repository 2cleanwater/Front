
import 'bootstrap/dist/css/bootstrap.css';

// npm i react-router react-router-dom
// npm i react-loader-spinner

function App() {
  const user = {name: 'HungBu', age: 20};
  const ary = ['a', 'b', 'c'];
  const onPlus = (x, y) => {
    return `${x} + ${y} = ${x + y}`;
  }

  return (
    <div className="card-body">
      
    </div>
  );
}

export default App;
